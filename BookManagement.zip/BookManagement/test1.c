//
// Created by 陈浩东 on 2021/3/15.
//
#include <stdio.h>

int main(){
    char buffer[20];
    fgets(buffer, (sizeof buffer / sizeof buffer[0]), stdin);
    printf("s\n", buffer);
}
