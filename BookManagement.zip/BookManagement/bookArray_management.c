//
// Created by 陈浩东 on 2021/3/11.
//
#include "book_management.h"
#include <stdlib.h>

/*Operations on BookArray*/
BookArray* BookArray_new()
{
    BookArray* tempNode = (BookArray*)malloc(sizeof(BookArray));
//    tempNode->array = Book_new();
    if(tempNode == NULL)
    {
        printf("error -> BookArray_new: failed to allocate ram for BookArray");
        return NULL;
    }
    return tempNode;
}
BookArray* BookArray_newWithValue(Book* book)
{
    BookArray* tempNode = BookArray_new();
    if(tempNode == NULL)
        return NULL;
    tempNode->length = 5;
    tempNode->array = Book_newWithValue(book->id, book->title, book->authors, book->year, book->copies);
    return tempNode;
}

BookArray* BookArray_newWithValueAndIndex(Book* book, BookArray* piror, BookArray* next)
{
    BookArray* tempNode = BookArray_new();
    if(tempNode == NULL)
        return NULL;
    tempNode->piror = piror;
    tempNode->next = next;
    tempNode->length = 5;
    tempNode->array = Book_newWithValue(book->id, book->title, book->authors, book->year, book->copies);
    return tempNode;
}

void BookArray_free(BookArray* target)
{
    if(target == NULL)
    {
        printf("error -> BookArray_free: target is NULL\n");
        return;
    }
    Book_free(target->array);
    free(target);
}

void BookArray_setIndex(BookArray* target, BookArray* next, BookArray* piror)
{
    if(target == NULL)
    {
        printf("error -> BookArray_setIndex: target is NULL\n");
        return;
    }
    target->piror = piror;
    target->next = next;
}

void BookArray_setValue(BookArray* target, Book* array)
{
    if(target == NULL)
    {
        printf("error -> BookArray_setvalue: target is NULL\n");
        return;
    }
    if(array == NULL)
    {
        printf("error -> BookArray_setvalue: array is NULL\n");
        return;
    }
    target->array = array;
}

void BookArray_set(BookArray* target, Book* array, BookArray* next, BookArray* piror)
{
    BookArray_setIndex(target, next, piror);
    BookArray_setValue(target, array);
}

Book* BookArray_getArray(BookArray* target)
{
    if(target == NULL)
    {
        printf("error -> BookArray_getArray: target is NULL\n");
        return NULL;
    }
    return target->array;
}

BookArray* BookArray_getPiror(BookArray* target)
{
    return target->piror;
}

BookArray* BookArray_getNext(BookArray* target)
{
    return target->next;
}

unsigned int BookArray_getLength(BookArray* target)
{
    return target->length;
}
/*Operations on BookArray*/
