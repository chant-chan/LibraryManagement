//
// Created by 陈浩东 on 2021/3/15.
//
#include "book_management.h"
#include <string.h>
#include <stdio.h>
void command_addBook()
{
    printf("please enter the title of the book to add:\n");
    char title[100];
    gets(title);
    printf("please enter the author of the book to add:\n");
    char authors[100];
    gets(authors);
    printf("please enter the year of the book to add:\n");
    unsigned int year;
    scanf("%d", &year);
    getchar();
    printf("please enter the copies of the book to add:\n");
    unsigned int copies;
    scanf("%d", &copies);
    getchar();
    Book* tempBook = Book_newWithValue(bookList->size + 1, title, authors, year, copies);
   /* BookArray* tempNode = bookList->head->next;
    for(unsigned int i = 0; i < bookList->size; ++i)
    {
        if((strcmp(tempBook->title, tempNode->array->title) == 0) && (strcmp(tempBook->authors, tempNode->array->authors) == 0) &&
                (tempBook->year == tempNode->array->year))
        {
            ++(tempNode->array->copies);
            printf("successfully add book copies.\n");
            Book_free(tempBook);
            return;
        }
        tempNode = tempNode->next;
    }*/
    BookLinkedList_addArray(bookList, tempBook);
/*    printf("command_addBook > bookList->tail->piror->array->id: %d \n", bookList->tail->piror->array->id);
    printf("command_addBook > bookList->tail->piror->array->title: %s \n", bookList->tail->piror->array->title);
    printf("command_addBook > bookList->tail->piror->array->authors: %s \n", bookList->tail->piror->array->authors);
    printf("command_addBook > bookList->tail->piror->array->year: %d \n", bookList->tail->piror->array->year);
    printf("command_addBook > bookList->tail->piror->array->copies: %d \n", bookList->tail->piror->array->copies);
    printf("bookList->tail->piror address is %d\n", bookList->tail->piror);*/
    printf("successfully added a new book.\n");
}
void command_remove()
{
    command_show();
    printf("please enter the id of book to remove:\n");
    unsigned int id;
    int ret = scanf("%d", &id);
    getchar();
    if(ret == 0)
    {
        printf("please intput an integer\n");
        return;
    }
    BookLinkedList_removeAndFree(bookList, id);
}

void command_store()
{
    FILE* file;
    if(store_books(file))
    {
        printf("Sorry, unable to store books.\n");
        return;
    }
    if(userLinkedList_store(file))
    {
        printf("Sorry, unable to store userList.\n");
        return;
    }
    printf("Successfully stored books!\n");
    command_showUser();
    command_show();
}

void command_load()
{
    FILE* file;
    if(load_books(file))
    {
        printf("Sorry, unable to load books.\n");
        return;
    }
    if(userLinkedList_load(file))
    {
        printf("Sorry, unable to load books.\n");
        return;
    }
    printf("Successfully loaded books and user list!\n");
    command_show();
    command_showUser();
}

void command_show()
{
    BookArray* tempNode = bookList->head->next;
    if(tempNode == NULL || bookList->size == 0)
    {
        printf("Sorry, there is no book to be displayed.\n");
        return;
    }
    printf("id\ttitle\tauthors\tyear\tcopies\n");
    for(int i = 0; i < bookList->size; ++i)
    {
//        printf("command_show > tempNode %d address is %d\n", i, tempNode);
        printf("%d\t%s\t%s\t%d\t%d\n", tempNode->array->id, tempNode->array->title, tempNode->array->authors, tempNode->array->year, tempNode->array->copies);
        tempNode = tempNode->next;
    }
/*    printf("tempNode adr is %d\n", tempNode);
    printf("tail adr is %d\n", bookList->tail);
    tempNode = bookList->tail->piror;
    printf("==========\n");
    printf("tempNode adr is %d\n", tempNode);
    printf("head adr is %d\n", bookList->head);
    for(int i = 0; i < bookList->size; ++i)
    {
        printf("command_show > tempNode %d address is %d\n", tempNode->array->id, tempNode);
        printf("%d\t%s\t%s\t%d\t%d\n", tempNode->array->id, tempNode->array->title, tempNode->array->authors, tempNode->array->year, tempNode->array->copies);
        tempNode = tempNode->piror;
    }
    printf("tempNode adr is %d\n", tempNode);*/
}

void command_findBookbyTitle()
{
    printf("please enter the title of book:");
    char title[100];
    gets(title);
    BookLinkedList* booklistFound = BookLinkedList_findBookbyTitle(title);
    if(booklistFound->size == 0)
    {
        printf("Sorry , there is no book title named %s\n", title);
        return;
    }
    printf("Successfully find the book!\n");
    BookArray* tempNode = booklistFound->head->next;
    printf("id\ttitle\tauthors\tyear\tcopies\n");
    for(int i = 0; i < booklistFound->size; ++i)
    {
        printf("%d\t%s\t%s\t%d\t%d\n", tempNode->array->id, tempNode->array->title, tempNode->array->authors, tempNode->array->year, tempNode->array->copies);
        tempNode = tempNode->next;
    }
//    BookLinkedList_freeList(booklistFound);
}

void command_findBookbyAuthors() {
    printf("please enter the authors of book:");
    char authors[100];
    gets(authors);
    BookLinkedList *booklistFound = BookLinkedList_findBookbyAuthors(authors);
    if (booklistFound->size == 0) {
        printf("Sorry , there is no book authors named %s\n", authors);
        return;
    }
    printf("Successfully find the book!\n");
    BookArray *tempNode = booklistFound->head->next;
    printf("id\ttitle\tauthors\tyear\tcopies\n");
    for (int i = 0; i < booklistFound->size; ++i) {
        printf("%d\t%s\t%s\t%d\t%d\n", tempNode->array->id, tempNode->array->title, tempNode->array->authors,
               tempNode->array->year, tempNode->array->copies);
        tempNode = tempNode->next;
    }
//    BookLinkedList_freeList(booklistFound);
}

void command_findBookbyYear() {
    printf("please enter the year of book:");
    unsigned int year;
    scanf("%d", &year);
    getchar();
    BookLinkedList *booklistFound = BookLinkedList_findBookbyYear(year);
    if (booklistFound->size == 0) {
        printf("Sorry , there is no book year with %d\n", year);
        return;
    }
    printf("Successfully find the book!\n");
    BookArray *tempNode = booklistFound->head->next;
    printf("id\ttitle\tauthors\tyear\tcopies\n");
    for (int i = 0; i < booklistFound->size; ++i) {
        printf("%d\t%s\t%s\t%d\t%d\n", tempNode->array->id, tempNode->array->title, tempNode->array->authors,
               tempNode->array->year, tempNode->array->copies);
        tempNode = tempNode->next;
    }
    BookLinkedList_freeList(booklistFound);
    command_show();

}

void command_registerNewUser()
{
    printf("please enter the username\n");
    char username[100];
    gets(username);
    printf("please enter the password\n");
    char password[100];
    gets(password);
    User* tempUser = user_newWithValue(username, password);
    if(userLinkedList_addUser(userList, tempUser))
        return;
    printf("successfully register a new user.\n");
    command_showUser();
}

void command_showUser()
{
    User* tempUser = userList->head->next;
    if(tempUser == NULL || userList->size == 0)
    {
        printf("Sorry, there is no user to be displayed.\n");
        return;
    }
    printf("id\tusername\t\n");
    for(unsigned int i = 0; i < userList->size; ++i)
    {
        printf("%d\t%s\t\n", tempUser->id, tempUser->username);
        tempUser = tempUser->next;
    }
}

void command_removeUser()
{
    command_showUser();
    printf("please enter the id of user to remove\n");
    int id;
    scanf("%d", &id);
    getchar();
    if(userLinkedList_removeAndFree(userList, id))
        return;
    else
        printf("successfully remove the user.\n");
}

short command_userLogin() {
    printf("please enter your username:\n");
    char username[100];
    gets(username);
    printf("please enter your password:\n");
    char password[100];
    gets(password);
    if (userLinkedList_matchUsername(username) == NULL)
        return 1;
    if (user_checkPassword(userLinkedList_matchUsername(username), password))
        return 1;
    else {
        loginUser = userLinkedList_matchUsername(username);
        printf("successfully login.\n");
        return 0;
    }
}

void command_userLogout()
{
    loginUser = NULL;
    printf("successfully log out.\n");
}

void command_showUserBorrowedList()
{
    if(loginUser == NULL || loginUser->bookBorrowedList->size == 0)
    {
        printf("Sorry, the user has not borrowed book yet.\n");
        return;
    }
    BookArray* tempNode = loginUser->bookBorrowedList->head->next;
    printf("id\ttitle\tauthors\tyear\tcopies\n");
    for(int i = 0; i < loginUser->bookBorrowedList->size; ++i)
    {
//        printf("command_show > tempNode %d address is %d\n", i, tempNode);
        printf("%d\t%s\t%s\t%d\t%d\n", tempNode->array->id, tempNode->array->title, tempNode->array->authors, tempNode->array->year, tempNode->array->copies);
        tempNode = tempNode->next;
    }
}

void command_borrowBook()
{
    int id;
    printf("please enter the id of book you want to borrow.\n");
    scanf("%d", &id);
    getchar();
    if(bookList->size == 0)
    {
        printf("Sorry, there is no book to be borrowed.\n");
        return;
    }
    Book* bookToBorrow = BookLinkedList_getBook(bookList, id - 1);
    printf("func > command_borrowBook > bookToBorrow->id: %d\n", bookToBorrow->id);
    printf("func > command_borrowBook > bookToBorrow->title: %s\n", bookToBorrow->title);
    printf("func > command_borrowBook > bookToBorrow->author: %s\n", bookToBorrow->authors);
    if(bookToBorrow == NULL)
    {
        printf("No such book to be borrowed.\n");
        return;
    }
    if(user_borrowBook( loginUser, bookToBorrow))
        return;
    --(bookToBorrow->copies);
    printf("you have successfully borrowed book.\n");
}

void command_returnBook()
{
    command_showUserBorrowedList();
    if(loginUser->bookBorrowedList->size == 0)
        return;
    unsigned int id;
    printf("please enter the id of book you want to return.\n");
    scanf("%d", &id);
    getchar();
    if(user_returnBook(loginUser, id))
        return;
    printf("you have successfully returned book.\n");
    command_showUserBorrowedList();
    Book* bookToReturn = BookLinkedList_getBook(bookList, id - 1);
    printf("func > command_returnBook > bookToReturn->id %d", bookToReturn->id);
    ++(bookToReturn->copies);
}

void command_showBasicChoice()
{
    printf("Please choose an option:\n");
    printf("1) Register a new user\n");
    printf("2) Login\n");
    printf("3) Search for books\n");
    printf("4) Display all books\n");
    printf("5) Quit\n");
}

void command_showLibraryChoice()
{
    printf("Please choose an option:\n");
    printf("1) Add a book\n");
    printf("2) Remove a book\n");
    printf("3) Search for books\n");
    printf("4) Display all books\n");
    printf("5) log out\n");
}

void command_showUserChoice()
{
    printf("(Logged in as: %s\n", loginUser->username);
    printf("1) Borrow a book\n");
    printf("2) Return a book\n");
    printf("3) Search for books\n");
    printf("4) Display all books\n");
    printf("5) Log out\n");
}

void command_showSearchMenu()
{
        printf("Please choose an option:\n");
        printf("1) Find books by title\n");
        printf("2) Find books by author\n");
        printf("3) Find books by year\n");
        printf("4) Return to previous menu\n");
}