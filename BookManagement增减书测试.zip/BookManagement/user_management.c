//
// Created by 陈浩东 on 2021/3/17.
//
#include "book_management.h"
#include <stdlib.h>
#include <string.h>
/* Operations on users */
User* user_new()
{
    User* tempUser = (User*)malloc(sizeof(User));
    if(tempUser == NULL)
    {
        printf("error -> user_new: failed to allocate ram for tempUser.\n");
        return NULL;
    }
    tempUser->piror = NULL;
    tempUser->next = NULL;
    tempUser->authority = 0;
    tempUser->username = NULL;
    tempUser->usernameLength = 0;
    tempUser->password = NULL;
    tempUser->passwordLength = 0;
    tempUser->bookBorrowedList = BookLinkedList_new();
    return tempUser;
}

User* user_newLibrarian()
{
    User* tempUser = (User*)malloc(sizeof(User));
    if(tempUser == NULL)
    {
        printf("error -> user_new: failed to allocate ram for tempUser.\n");
        return NULL;
    }
    char* username = "Librarian";
    char* password = "Librarian";
    tempUser->piror = NULL;
    tempUser->next = NULL;
    tempUser->authority = 1;
    tempUser->username = (char*)malloc(sizeof(char) * 10);
    tempUser->usernameLength = 10;
    for(unsigned int i = 0; i < 10; ++i)
        *(tempUser->username + i) = *(username + i);
    tempUser->password = (char*)malloc(sizeof(char) * 10);
    tempUser->passwordLength = 10;
    for(unsigned int i = 0; i < 10; ++i)
        *(tempUser->password + i) = *(password + i);
    tempUser->bookBorrowedList = BookLinkedList_new();
    return tempUser;
}

/*User* user_newLibrarianAndIndex(unsigned int id, char* username, char* password, User* piror, User* next)
{
    User* tempLibrarian = user_newLibrarian();
    if(tempLibrarian == NULL)
        return NULL;
    tempLibrarian->id = id;
    tempLibrarian->piror = piror;
    tempLibrarian->next = next;
    return tempLibrarian;
}*/



User* user_newWithValue(char* username, char* password)
{
    User* tempUser =user_new();
    if(tempUser == NULL)
        return NULL;
    tempUser->usernameLength = (unsigned int)strlen(username);
    tempUser->username = (char*)malloc(sizeof(char) * (tempUser->usernameLength + 1));
    for(unsigned int i = tempUser->usernameLength, bound = -1; i != bound; --i)
        *(tempUser->username + i) = *(username + i);
    tempUser->passwordLength = (unsigned int)strlen(password);
    tempUser->password = (char*)malloc(sizeof(char) * (tempUser->passwordLength + 1));
    for(unsigned int i = tempUser->passwordLength, bound = -1; i != bound; --i)
        *(tempUser->password + i) = *(password + i);
    return tempUser;
}

User* user_newWithValueAndIndex(unsigned int id, char* username, char* password, User* piror, User* next, int authority)
{
    User* tempUser = user_new();
    if(tempUser == NULL)
        return NULL;
    tempUser->usernameLength = (unsigned int)(strlen(username));
    tempUser->username = (char*)malloc(sizeof(char) * (tempUser->usernameLength + 1));
    for(unsigned int i = tempUser->usernameLength, bound = -1; i != bound; --i)
        *(tempUser->username + i) = *(username + i);
    tempUser->passwordLength = (unsigned int)(strlen(password));
    tempUser->password = (char*)malloc(sizeof(char) * (tempUser->passwordLength + 1));
    for(unsigned int i = tempUser->passwordLength, bound = -1; i != bound; --i)
        *(tempUser->password + i) = *(password + i);
    tempUser->next = next;
    tempUser->piror = piror;
    tempUser->id = id;
    tempUser->authority = authority;
    return tempUser;
}

void user_free(User* target)
{
    if(target == NULL)
    {
        printf("error -> user_free: target to free is NULL.\n");
        return;
    }
    BookLinkedList_free(target->bookBorrowedList);
    printf("BookLinkedList free successfully.\n");
    target->piror->next = target->next;
    target->next->piror = target->piror;
    printf("target->username: %s\n", target->username);
    printf("target->password: %s\n", target->password);
    free(target->username);
    printf("user name free successfully.\n");
    free(target->password);
    free(target);
}

User* user_getPiror(User* target)
{
    if(target == NULL)
    {
        printf("error -> user_getPiror: target is NULL.\n");
        return NULL;
    }
    return target->piror;
}

User* user_getNext(User* target)
{
    if(target == NULL)
    {
        printf("error -> user_getNext: target is NULL.\n");
        return NULL;
    }
    return target->next;
}

char* user_getUsername(User* target)
{
    if(target == NULL)
    {
        printf("error -> user_getUsername: target is NULL.\n");
        return NULL;
    }
    return target->username;
}

char* user_getPassword(User* target)
{
    if(target == NULL)
    {
        printf("error -> user_getPassword: target is NULL.\n");
        return NULL;
    }
    return target->password;
}

int user_getAuthority(User* target)
{
    if(target == NULL)
    {
        printf("error -> user_getAuthority: target is NULL.\n");
        return 1;
    }
    return target->authority;
}

BookLinkedList* user_getBookBorrowedList(User* target)
{
    if(target == NULL)
    {
        printf("error -> user_getBookBorrowedList: target is NULL.\n");
        return NULL;
    }
/*    printf("func > user_getBookBorrowedList > command show.\n");
    command_show();*/
    return target->bookBorrowedList;
}

short user_borrowBook(User* target, Book* book)
{
    if(target == NULL || book == NULL)
        return 1;
    BookArray* tempNode = target->bookBorrowedList->head->next;
    for(int i = 0; i < target->bookBorrowedList->size; ++i)
    {
        if(strcmp(Book_getTitle(tempNode->array), Book_getTitle(book)) == 0)
        {
            printf("Sorry, you already have a copy of this book on loan.\n");
            return 1;
        }
        tempNode = tempNode->next;
    }
/*    printf("func > user_borrowBook > command show:\n");
    command_show();*/
    BookLinkedList_addBorrowedArray(user_getBookBorrowedList(target), book);
    return 0;
}

short user_returnBook(User* target, unsigned int id)
{
    if(target == NULL || index <= 0)
        return 1;
    BookArray* tempNode = target->bookBorrowedList->head->next;
//    printf("func > user_returnBook > target->bookBorrowedList > size: %d\n", target->bookBorrowedList->size);
    for(int i = 0; i < target->bookBorrowedList->size; ++i)
    {
        if(Book_getID(tempNode->array) == id)
        {
            printf("func> Book_getID ran successfully\n");
            BookLinkedList_removeFromBookBorrowedList(target->bookBorrowedList, i + 1);
            ++(tempNode->array->copies);
            printf("Returned book successfully.\n");
            return 0;
        }
        tempNode = tempNode->next;
    }
    printf("Sorry, the book to be returned were not found.\n");
    return 1;
}

short user_checkPassword(User* user, char* password)
{
    if(user == NULL)
    {
        printf("error > user_checkPassword : user is NULL\n");
        return 1;
    }
    if(strcmp(user->password, password) == 0)
        return 0;
    else
    {
        printf("Sorry, you have enter a wrong password.\n");
        return 1;
    }
}
/* Operations on users */




