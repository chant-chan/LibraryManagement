//
// Created by 陈浩东 on 2021/3/15.
//
#include "book_management.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
    FILE *file;
    Book* book = Book_newWithValue(1, "hello", "world", 2019, 3);
    book->titleLength = strlen("hello");
    book->authorsLength = strlen("world");
    printf("%d\t", book->id);
    printf("%d\t", book->titleLength);
    printf("%s\t", book->title);
    printf("%d\t", book->authorsLength);
    printf("%s\t", book->authors);
    printf("%d\t", book->year);
    printf("%d\n", book->copies);
    file = fopen("book.bin", "wb+");
    fwrite(&(book->id), sizeof(unsigned int), 1, file);
    fwrite(&(book->titleLength), sizeof(unsigned int), 1 ,file);
    fwrite(book->title,  (book->titleLength + 1) * sizeof(char), 1, file);
    fwrite(&(book->authorsLength), sizeof(unsigned int), 1, file);
    fwrite(book->authors, (book->authorsLength + 1) * sizeof(char ), 1, file);
    fwrite(&(book->year), sizeof(unsigned int ), 1, file);
    fwrite(&(book->copies), sizeof(unsigned int ), 1, file);
    fclose(file);
    file = fopen("book.bin", "rb+");
    Book* newBook = Book_new();
    fread(&(newBook->id), sizeof(unsigned int), 1, file);
    fread(&(newBook->titleLength), sizeof(unsigned int), 1, file);
    newBook->title = (char*)malloc(sizeof(char) * newBook->titleLength);
    fread(newBook->title, (newBook->titleLength + 1) * sizeof(char), 1, file);
    fread(&(newBook->authorsLength), sizeof(unsigned int), 1, file);
    newBook->authors = (char*)malloc(sizeof(char) * (newBook->authorsLength));
    fread(newBook->authors, (newBook->authorsLength + 1) * sizeof(char), 1, file);
    fread(&(newBook->year), sizeof(unsigned int), 1, file);
    fread(&(newBook->copies), sizeof(unsigned int), 1, file);
    printf("%d\t", newBook->id);
    printf("%s\t", newBook->title);
    printf("%s\t", newBook->authors);
    printf("%d\t", newBook->year);
    printf("%d\n", newBook->copies);
    fclose(file);
    char str[100];
    if(fgets(str, 99, stdin) == NULL)
    {
        printf("too more ch\n");
    }
    printf("%s\n", str);
    return 1;
}
