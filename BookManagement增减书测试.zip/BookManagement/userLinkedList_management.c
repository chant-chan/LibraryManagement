//
// Created by 陈浩东 on 2021/3/17.
//
#include "book_management.h"
#include <stdlib.h>
#include <string.h>
UserLinkedList* userList;
/* Operations on userLinkedList */
UserLinkedList* userLinkedList_new()
{
    UserLinkedList* tempList = (UserLinkedList*)malloc(sizeof(UserLinkedList));
    if(tempList == NULL)
    {
        printf("error > userLinkedList_new: failed to allocate ram for tempList.\n");
        return NULL;
    }
    tempList->size = 0;
    tempList->head = user_new();
    tempList->tail = user_new();
    tempList->head->next = tempList->tail;
    tempList->tail->piror = tempList->head;
    return tempList;
}

short userLinkedList_free(UserLinkedList* target)
{
    if(target == NULL)
    {
        printf("error > userLinkedList_free: target to free is NULL.\n");
        return 1;
    }
    if(target->size == 0)
        return 1;
    User* tempNode = target->head->next, *nextTofree;
    for(int i = 0; i < target->size; ++i)
    {
        nextTofree = tempNode->next;
        user_free(tempNode);
        tempNode = nextTofree;
    }
    free(target->head);
    free(target->tail);
    target->size = 0;
    printf("userLinkedList_free worked successfully!\n");
    return 0;
}

void userLinkedList_freeList(UserLinkedList* target)
{
    User* tempNode = target->head->next, *nextToFree;
    for(int i = 0;i < target->size; ++i)
    {
        nextToFree = tempNode->next;
        user_free(tempNode);
        tempNode = nextToFree;
    }
    free(target);
}

short userLinkedList_addUser(UserLinkedList* target, User* user)
{
    User* tempNode = target->head->next;
    for(unsigned int i = 0; i < target->size; ++i)
    {
        if(strcmp(tempNode->username, user->username) == 0)
        {
            printf("user name has already existed, please try again.\n");
            return 1;
        }
        tempNode = tempNode->next;
    }
    User* tempUser = user_newWithValueAndIndex(userList->size + 1, user->username,user->password, target->tail->piror, target->tail, user->authority);
    if(tempUser == NULL)
    {
        printf("error > userLinkedList_addUser: failed to allocate ram for tempUser.\n");
        return 1;
    }
    target->tail->piror->next = tempUser;
    target->tail->piror = tempUser;
    ++(target->size);
    return 0;
}

short userLinkedList_loadUser(UserLinkedList* target, User* user)
{
    User* tempUser = user_newWithValueAndIndex(user->id, user->username,user->password, target->tail->piror, target->tail, user->authority);
    if(tempUser == NULL)
    {
        printf("error > userLinkedList_loadUser: failed to allocate ram for tempUser.\n");
        return 1;
    }
    target->tail->piror->next = tempUser;
    target->tail->piror = tempUser;
//    ++(target->size);
    return 0;
}

User* userLinkedList_getUserByIndex(UserLinkedList* target, int index)
{
    User* tempUser = target->head->next;
    for(int i = 0; i < index; ++i)
        tempUser =tempUser->next;
    return tempUser;
}

short userLinkedList_removeAndFree(UserLinkedList* target, int index)
{
    User* tempUser = userLinkedList_getUserByIndex(target, index - 1);
    if(tempUser->bookBorrowedList->size != 0)
    {
        printf("Sorry, the user to be removed has borrowed books, you can't remove the user.\n");
        return 1;
    }
    tempUser->piror->next = tempUser->next;
    tempUser->next->piror = tempUser->piror;
    --(target->size);
    user_free(tempUser);
    tempUser = target->tail->next;
    for(unsigned int i = 0; i < target->size; ++i)
    {
        tempUser->id = (i + 1);
        tempUser = tempUser->next;
    }
    return 0;
}

unsigned int userLinkedList_getSize(UserLinkedList* target)
{
    return target->size;
}

User* userLinkedList_matchUsername(char* username)
{
    User* tempUser = userList->head->next;
    for(unsigned int i = 0; i < userList->size; ++i)
    {
        if(strcmp(username, tempUser->username) == 0)
            return tempUser;
        tempUser = tempUser->next;
    }
    printf("Sorry, no such username.\n");
    return NULL;
}

short userLinkedList_store(FILE* file)
{
    file = fopen("userList.bin", "wb+");
    if(file == NULL)
        return 1;
    fwrite(&(userList->size), sizeof(unsigned int), 1, file);
    printf("func > userLinkedList_store > userList->size: %d\n", userList->size);
    User* tempUser = userList->head->next;
    for(unsigned int i = userList->size, bound = 0; i != bound; --i)
    {
        fwrite(&(tempUser->id), sizeof(unsigned int), 1, file);
        fwrite(&(tempUser->authority), sizeof(int), 1, file);
        fwrite(&(tempUser->usernameLength), sizeof(unsigned int), 1, file);
        fwrite(tempUser->username, sizeof(char) * (tempUser->usernameLength + 1), 1, file);
        fwrite(&(tempUser->passwordLength), sizeof(unsigned int), 1, file);
        fwrite(tempUser->password, sizeof(char) * (tempUser->passwordLength + 1), 1, file);
        fwrite(&(tempUser->bookBorrowedList->size), sizeof(unsigned int), 1, file);
        BookArray* tempNode = tempUser->bookBorrowedList->head->next;
        printf("func > userLinkedList_store > tempUser->bookBorrowedList->size: %d\n", tempUser->bookBorrowedList->size);
/*        for(unsigned int j = 0; i < tempUser->bookBorrowedList->size; ++i)
        {
            fwrite(&(tempNode->array->id), sizeof(unsigned int), 1, file);
            fwrite(&(tempNode->array->titleLength), sizeof(unsigned int), 1, file);
            fwrite(tempNode->array->title, sizeof(char) * (tempNode->array->titleLength + 1), 1, file);
            fwrite(&(tempNode->array->authorsLength), sizeof(unsigned int), 1, file);
            fwrite(tempNode->array->authors, sizeof(char) * (tempNode->array->authorsLength + 1), 1 ,file);
            fwrite(&(tempNode->array->year), sizeof(unsigned int), 1, file);
            fwrite(&(tempNode->array->copies), sizeof(unsigned int), 1, file);
            fwrite(&(tempNode->array->borrowed), sizeof(int), 1, file);
            tempNode = tempNode->next;
        }*/
        for(unsigned int j = tempUser->bookBorrowedList->size, bound = 0; j != bound; --j)
        {
            fwrite(&(tempNode->array->id), sizeof(unsigned int), 1, file);
            fwrite(&(tempNode->array->titleLength), sizeof(unsigned int), 1, file);
            fwrite(tempNode->array->title, sizeof(char) * (tempNode->array->titleLength + 1), 1, file);
            fwrite(&(tempNode->array->authorsLength), sizeof(unsigned int), 1, file);
            fwrite(tempNode->array->authors, sizeof(char) * (tempNode->array->authorsLength + 1), 1 ,file);
            fwrite(&(tempNode->array->year), sizeof(unsigned int), 1, file);
            fwrite(&(tempNode->array->copies), sizeof(unsigned int), 1, file);
            fwrite(&(tempNode->array->borrowed), sizeof(int), 1, file);
            tempNode = tempNode->next;
        }
        printf("func > userLinkedList_store > tempUser->bookBorrowedList->size: %d\n", tempUser->bookBorrowedList->size);
        tempUser = tempUser->next;
    }
    if(fclose(file) != 0)
        return 1;
    printf("successfully store user list.\n");
    return 0;
}

short userLinkedList_load(FILE* file)
{
    file = fopen("userList.bin","rb+");
    if(file == NULL)
        return 1;
    if(userLinkedList_free(userList) == 0)
        userList = userLinkedList_new();
    fread(&(userList->size), sizeof(unsigned int), 1, file);
    unsigned int size = userList->size;
    printf("user list -> size is %d\n", userList->size);
    for(unsigned int i = 0; i < size; ++i)
    {
        printf("func > userLinkedList_load loops in.\n");
        User* tempUser = user_new();
        printf("tempUser new successfully.\n");
        fread(&(tempUser->id), sizeof(unsigned int), 1, file);
        printf("func > userLinkedList_load loops > tempUser->id: %d\n", tempUser->id);
        fread(&(tempUser->authority), sizeof(int), 1, file);
        printf("func > userLinkedList_load loops > tempUser->authority: %d\n", tempUser->authority);
        fread(&(tempUser->usernameLength), sizeof(unsigned int), 1, file);
        printf("func > userLinkedList_load loops > tempUser->usernameLength: %d\n", tempUser->usernameLength);
        tempUser->username = (char*)malloc(sizeof(char) * (tempUser->usernameLength + 1));
        fread(tempUser->username, sizeof(char) * (tempUser->usernameLength + 1), 1, file);
        printf("func > userLinkedList_load loops > tempUser->username: %s\n", tempUser->username);
        fread(&(tempUser->passwordLength), sizeof(unsigned int), 1, file);
        tempUser->password = (char*)malloc(sizeof(char) * (tempUser->passwordLength + 1));
        printf("func > userLinkedList_load loops > tempUser->passwordLength: %d\n", tempUser->passwordLength);
        fread(tempUser->password, sizeof(char) * (tempUser->passwordLength + 1), 1, file);
        printf("func > userLinkedList_load loops > tempUser->password: %s\n", tempUser->password);
        fread(&(tempUser->bookBorrowedList->size), sizeof(unsigned int), 1, file);
        printf("func > userLinkedList_load loops > tempUser->bookBorrowedList->size: %d\n", tempUser->bookBorrowedList->size);
        userLinkedList_loadUser(userList, tempUser);
        User* lastUser = userList->tail->piror;
        for(unsigned int j = tempUser->bookBorrowedList->size, bound = 0; j != bound; --j)
        {
            Book* book = Book_new();
            printf("%d book new successfully.\n", j);
            if(book == NULL)
                return 1;
            fread(&(book->id), sizeof(unsigned int), 1, file);
            printf("func > userLinkedList_load > j loops > book->id: %d\n", book->id);
            fread(&(book->titleLength), sizeof(unsigned int), 1, file);
            printf("func > userLinkedList_load > j loops > book->titleLength: %d\n", book->titleLength);
            book->title = (char*)malloc(sizeof(char) * (book->titleLength + 1));
            fread(book->title, sizeof(char) * (book->titleLength + 1), 1, file);
            printf("func > userLinkedList_load > j loops > book->title: %s\n", book->title);
            fread(&(book->authorsLength), sizeof(unsigned int), 1, file);
            printf("func > userLinkedList_load > j loops > book->authorslength: %d\n", book->authorsLength);
            book->authors = (char*)malloc(sizeof(char) * (book->authorsLength + 1));
            fread(book->authors, sizeof(char) * (book->authorsLength + 1), 1, file);
            printf("func > userLinkedList_load > j loops > book->authors: %s\n", book->authors);
            fread(&(book->year), sizeof(unsigned int), 1, file);
            printf("func > userLinkedList_load > j loops > book->year: %d\n", book->year);
            fread(&(book->copies), sizeof(unsigned int), 1, file);
            printf("func > userLinkedList_load > j loops > book->copies: %d\n", book->copies);
            fread(&(book->borrowed),sizeof(int), 1, file);
            printf("func > userLinkedList_load > j loops > book->borrowed: %d\n", book->borrowed);
            BookLinkedList_loadArray(lastUser->bookBorrowedList, book);
            Book_free(book);
        }

        free(tempUser->bookBorrowedList);
        free(tempUser->username);
        free(tempUser->password);
        free(tempUser);
    }
    printf("successfully load userList.\n");
    if(fclose(file) != 0)
        return 1;
    return 0;
}
/* Operations on userLinkedList */
