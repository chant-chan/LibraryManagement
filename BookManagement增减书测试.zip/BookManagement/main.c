//
// Created by 陈浩东 on 2021/3/10.
//
#include "book_management.h"
#include <stdio.h>`

int main() {
    bookList = BookLinkedList_new();
    userList = userLinkedList_new();/*
    User* librarian = user_newLibrarian();
    userLinkedList_addUser(userList, librarian);
    (librarian = userList->head->next)->authority = 1;*/
//    command_store();
    command_load();/*
    Book* book1 = Book_newWithValue(1, "hello", "world", 2018, 3);
    Book* book2 = Book_newWithValue(2, "hi", "c", 2019, 4);
    Book* book3 = Book_newWithValue(3, "good", "morning", 2020, 5);
    BookLinkedList_addArray(bookList, book1);
    BookLinkedList_addArray(bookList, book2);
    BookLinkedList_addArray(bookList, book3);*/
    int choice = 0;
    int ret;
    while(1)
    {
        command_showBasicChoice();
        printf(" Option:");
        ret = scanf("%d", &choice);
        getchar();
        if(choice == 1)
        {
            command_registerNewUser();
        }
        else if(choice == 2)
        {
            if(!command_userLogin())
            {
                printf("loginUser->authority: %d\n", loginUser->authority);
                if(loginUser->authority == 1)
                {
                    for (;;)
                    {
                        command_showLibraryChoice();
                        printf("Option:");
                        scanf("%d", &choice);
                        getchar();
                        if (choice == 1)
                        {
                            command_addBook();
                        }
                        else if (choice == 2)
                        {
                            command_remove();
                        }
                        else if (choice == 3)
                        {
                            for (;;)
                            {
                                command_showSearchMenu();
                                printf("Option:");
                                scanf("%d", &choice);
                                getchar();
                                if (choice == 1)
                                {
                                    command_findBookbyTitle();
                                }
                                else if (choice == 2)
                                {
                                    command_findBookbyAuthors();
                                }
                                else if (choice == 3)
                                {
                                    command_findBookbyYear();
                                }
                                else if (choice == 4)
                                {
                                    break;
                                }
                                else
                                {
                                    printf("No such command.\n");
                                }
                            }
                        }
                        else if (choice == 4)
                        {
                            command_show();
                        }
                        else if (choice == 5)
                        {
                            command_userLogout();
                            break;
                        }
                        else
                        {
                            printf("No such command, please enter again.\n");
                        }
                    }
                }
                else
                {
                    for(;;)
                    {
                        command_showUserChoice();
                        printf("Option:");
                        scanf("%d", &choice);
                        getchar();
                        if(choice == 1)
                        {
                            command_borrowBook();
                            command_show();
                        }
                        else if(choice == 2)
                        {
                            command_returnBook();
                        }
                        else if(choice == 3)
                        {
                            for (;;)
                            {
                                command_showSearchMenu();
                                printf("Option:");
                                scanf("%d", &choice);
                                getchar();
                                if (choice == 1)
                                {
                                    command_findBookbyTitle();
                                }
                                else if (choice == 2)
                                {
                                    command_findBookbyAuthors();
                                }
                                else if (choice == 3)
                                {
                                    command_findBookbyYear();
                                }
                                else if (choice == 4)
                                {
                                    break;
                                }
                                else
                                {
                                    printf("No such command.\n");
                                }
                            }
                        }
                        else if(choice == 4)
                        {
                            command_show();
                        }
                        else if(choice == 5)
                        {
                            command_userLogout();
                            break;
                        }
                        else
                        {
                            printf("No such command, please enter again.\n");
                        }
                    }
                }
            }

        }
        else if(choice == 3)
        {
            for(;;)
            {
                command_showSearchMenu();
                printf("Option:");
                scanf("%d", &choice);
                getchar();
                if (choice == 1)
                {
                    command_findBookbyTitle();
                } else if (choice == 2)
                {
                    command_findBookbyAuthors();
                } else if (choice == 3)
                {
                    command_findBookbyYear();
                } else if (choice == 4)
                {
                    break;
                }
                else{
                    printf("No such command, please enter again\n");
                }
            }
        }
        else if(choice == 4)
        {
            command_show();
        }
        else if(choice == 5)
        {
            command_store();
            return 0;
        }
        else
        {
            printf("No such command, please enter again.\n");
        }
    }
}
