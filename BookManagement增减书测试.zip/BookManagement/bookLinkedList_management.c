#include <__wctype.h>
//
// Created by 陈浩东 on 2021/3/11.
//
#include "book_management.h"
#include <stdlib.h>
#include <string.h>
BookLinkedList* bookList;
User* loginUser;
/* Operations on BookLinkedList */

BookLinkedList* BookLinkedList_new()
{
    BookLinkedList* tempPointer = (BookLinkedList*)malloc(sizeof(BookLinkedList));
    if(tempPointer == NULL)
    {
        printf("error -> BookLinkedList_new: failed to allocate ram for BookLinkedList\n");
        return NULL;
    }
    tempPointer->size = 0;
    tempPointer->head = BookArray_new();
    tempPointer->tail = BookArray_new();
    tempPointer->head->next = tempPointer->tail;
    tempPointer->tail->piror = tempPointer->head;
    return tempPointer;
}

short BookLinkedList_free(BookLinkedList* target)
{
    if(target->size == 0)
        return 1;
    BookArray* tempNode = target->head->next, *nextToFree;
    for(int i = 0;i < target->size; ++i)
    {
        nextToFree = tempNode->next;
        BookArray_free(tempNode);
        tempNode = nextToFree;
    }
    free(target->head);
    free(target->tail);
    target->size = 0;
    printf("BookLinkedList_free worked successfully\n");
    return 0;
}
void BookLinkedList_freeList(BookLinkedList* target)
{
    BookArray* tempNode = target->head->next, *nextToFree;
    for(int i = 0;i < target->size; ++i)
    {
        nextToFree = tempNode->next;
        BookArray_free(tempNode);
        tempNode = nextToFree;
    }
    free(target);
}

short BookLinkedList_addArray(BookLinkedList* target, Book* book)
{
    BookArray* tempNode = target->head->next;
    for(unsigned int i = 0; i < target->size; ++i)
    {
        if((strcmp(tempNode->array->title, book->title) == 0) && (strcmp(tempNode->array->authors, book->authors) == 0)
        && (tempNode->array->year == book->year))
        {
            tempNode->array->copies += book->copies;
            printf("successfully add book copies.\n");
            Book_free(book);
            return 0;
        }
        tempNode = tempNode->next;
    }
    BookArray* nodeToAdd = BookArray_newWithValueAndIndex(book, target->tail->piror, target->tail);
    if(nodeToAdd == NULL)
    {
        printf("error ->  BookLinkedList_addArray: failed to add node for BookLinkedList\n");
        return 1;
    }

    target->tail->piror->next = nodeToAdd;
    target->tail->piror = nodeToAdd;
/*    printf("BookLinkedList_addArray > target->tail->piror->next->array->id %d\n", target->tail->piror->next->array->id);
    printf("BookLinkedList_addArray > target->tail->piror->next->array->title %s\n", target->tail->piror->next->array->title);
    printf("BookLinkedList_addArray > target->tail->piror->next->array->author %s\n", target->tail->piror->next->array->authors);
    printf("BookLinkedList_addArray > target->tail->piror->next->array->year %d\n", target->tail->piror->next->array->year);
    printf("BookLinkedList_addArray > target->tail->piror->next->array->copies %d\n", target->tail->piror->next->array->copies);*/
/*    printf("BookLinkedList_addArray > target->tail->piror->array->id: %d \n", target->tail->piror->array->id);
    printf("BookLinkedList_addArray > target->tail->piror->array->title: %s \n", target->tail->piror->array->title);
    printf("BookLinkedList_addArray > target->tail->piror->array->authors: %s \n", target->tail->piror->array->authors);
    printf("BookLinkedList_addArray > target->tail->piror->array->year: %d \n", target->tail->piror->array->year);
    printf("BookLinkedList_addArray > target->tail->piror->array->copies: %d \n", target->tail->piror->array->copies);*/
    ++(target->size);
    Book_free(book);
    return 0;
}

short BookLinkedList_addBorrowedArray(BookLinkedList* target, Book* book)
{
    BookArray* tempNode = target->head->next;
/*    for(unsigned int i = 0; i < target->size; ++i)
    {
        if((strcmp(tempNode->array->title, book->title) == 0) && (strcmp(tempNode->array->authors, book->authors) == 0)
           && (tempNode->array->year == book->year))
        {
            tempNode->array->copies += book->copies;
            printf("successfully add book copies.\n");
            Book_free(book);
            return 0;
        }
        tempNode = tempNode->next;
    }*/
    BookArray* nodeToAdd = BookArray_newWithValueAndIndex(book, target->tail->piror, target->tail);
    nodeToAdd->array->copies = 1;
    if(nodeToAdd == NULL)
    {
        printf("error ->  BookLinkedList_addArray: failed to add node for BookLinkedList\n");
        return 1;
    }

    target->tail->piror->next = nodeToAdd;
    target->tail->piror = nodeToAdd;
/*    printf("BookLinkedList_addArray > target->tail->piror->next->array->id %d\n", target->tail->piror->next->array->id);
    printf("BookLinkedList_addArray > target->tail->piror->next->array->title %s\n", target->tail->piror->next->array->title);
    printf("BookLinkedList_addArray > target->tail->piror->next->array->author %s\n", target->tail->piror->next->array->authors);
    printf("BookLinkedList_addArray > target->tail->piror->next->array->year %d\n", target->tail->piror->next->array->year);
    printf("BookLinkedList_addArray > target->tail->piror->next->array->copies %d\n", target->tail->piror->next->array->copies);*/
/*    printf("BookLinkedList_addArray > target->tail->piror->array->id: %d \n", target->tail->piror->array->id);
    printf("BookLinkedList_addArray > target->tail->piror->array->title: %s \n", target->tail->piror->array->title);
    printf("BookLinkedList_addArray > target->tail->piror->array->authors: %s \n", target->tail->piror->array->authors);
    printf("BookLinkedList_addArray > target->tail->piror->array->year: %d \n", target->tail->piror->array->year);
    printf("BookLinkedList_addArray > target->tail->piror->array->copies: %d \n", target->tail->piror->array->copies);*/
    ++(target->size);
/*    printf("func > BookLinkedList_addBorrowedArray > command show.\n");
    command_show();
    printf("func > BookLinkedList_addBorrowedArray > command show.\n");
    command_show();*/
    return 0;
}

short BookLinkedList_loadArray(BookLinkedList* target, Book* book)
{
/*    BookArray* tempNode = BookArray_newWithValueAndIndex(book, target->tail->piror, target->tail);
    if(tempNode == NULL)
    {
        printf("error ->  BookLinkedList_loadArray: failed to add node for BookLinkedList\n");
        return 1;
    }
    target->tail->piror->next = tempNode;
    target->tail->piror = tempNode;
    return 0;*/
    BookArray* nodeToAdd = BookArray_newWithValueAndIndex(book, target->tail->piror, target->tail);
    if(nodeToAdd == NULL)
    {
        printf("error ->  BookLinkedList_addArray: failed to add node for BookLinkedList\n");
        return 1;
    }

    target->tail->piror->next = nodeToAdd;
    target->tail->piror = nodeToAdd;
    ++(target->size);
    return 0;
}

BookArray* BookLinkedList_getBookArray(BookLinkedList* target, int index) {
    BookArray *tempNode = target->head->next;
    printf("func > BookLinkedList_getBookArray > size is %d\n", target->size);
    printf("func > BookLinkedList_getBookArray > index is %d\n", index);
    if (target->size < index) {
        printf("func > BookLinkedList_getBookArray > index out of bounds.\n");
        return NULL;
    }
    for (int i = 0; i < index; ++i)
    {
        printf("i is %d\n", i);
        printf("func> BookLinkedList_getBookArray > tempNode->title: %s\n", tempNode->array->title);
        printf("func> BookLinkedList_getBookArray > tempNode->authors: %s\n", tempNode->array->authors);
        tempNode = tempNode->next;
    }

    return tempNode;
}

Book* BookLinkedList_getBook(BookLinkedList* target, int index)
{
    BookArray* tempArray = BookLinkedList_getBookArray(target, index);
    if(tempArray == NULL)
        return NULL;
    return tempArray->array;
}

void BookLinkedList_removeAndFree(BookLinkedList* target, unsigned int index)
{
    BookArray* tempNode = BookLinkedList_getBookArray(target, index -  1);
    if(tempNode->array->borrowed == 1)
    {
        printf("Sorry, the book has been borrowed, you can't remove it from book list\n");
        return;
    }
    tempNode->piror->next = tempNode->next;
    tempNode->next->piror = tempNode->piror;
    --(target->size);
    BookArray_free(tempNode);
    tempNode = target->head->next;
    for(int i = 0; i < target->size; ++i)
    {
        tempNode->array->id = (i + 1);
        tempNode = tempNode->next;
    }
}

void BookLinkedList_removeFromBookBorrowedList(BookLinkedList* target, unsigned int index)
{
    BookArray* tempNode = BookLinkedList_getBookArray(target, index -  1);
    if(tempNode->array->borrowed == 1)
    {
        printf("Sorry, the book has been borrowed, you can't remove it from book list\n");
        return;
    }
    tempNode->piror->next = tempNode->next;
    tempNode->next->piror = tempNode->piror;
    --(target->size);
    BookArray_free(tempNode);
    tempNode = target->head->next;
/*    for(int i = 0; i < target->size; ++i)
    {
        tempNode->array->id = (i + 1);
        tempNode = tempNode->next;
    }*/
}

//用 toSet 替换 index 位置的节点tempNode
void BookLinkedList_setBookArray(BookLinkedList* target, BookArray* toSet, int index)
{
    BookArray* tempNode = BookLinkedList_getBookArray(target, index);
    tempNode->piror->next = toSet;
    tempNode->next->piror = toSet;
    toSet->piror = tempNode->piror;
    toSet->next = tempNode->next;
}

void BookLinkedList_setBook(BookLinkedList* target, Book* book, int index)
{
    BookArray* tempNode = BookLinkedList_getBookArray(target, index);
    tempNode->array = book;
}
//在链表的第 index 节点后增加一个新的节点， 链表节点起始为head->next(index = 0)
void BookLinkedList_insertBookArray(BookLinkedList* target, BookArray* toInsert, int index)
{
    BookArray* tempNode = BookLinkedList_getBookArray(target, index);
    tempNode->next->piror = toInsert;
    toInsert->next = tempNode->next;
    tempNode->next = toInsert;
    toInsert->piror = tempNode;
    ++(target->size);
}

 unsigned int BookLinkedList_getSize(BookLinkedList* target)
{
    return (target->size);
}

int add_book(Book book)
{
    if(BookLinkedList_addArray(bookList, &book))
        return 1;
    return 0;
}
int remove_book(Book book)
{
    BookArray* tempNode = bookList->head->next;
    for(int i = 0; i < bookList->size; ++i)
    {
        if(tempNode->array->id == book.id && tempNode->array->title == book.title
        && tempNode->array->authors == book.authors && tempNode->array->year == book.year
        && tempNode->array->copies == book.copies )
        {
            BookLinkedList_removeAndFree(bookList, i);
            return 0;
        }
    }
    return 1;
}

BookLinkedList* BookLinkedList_findBookbyTitle(const char *title)
{
    int length = strlen(title);
    BookLinkedList* booklistFounded = BookLinkedList_new();
    BookArray* tempNode = bookList->head->next;
    for(int i = 0; i < bookList->size; ++i)
    {
        for(int k = 0; k < tempNode->array->titleLength; ++k)
        {
            if(length + k > tempNode->array->titleLength)
                break;
            if(strncmp(Book_getTitle(tempNode->array) + k, title, length) == 0)
            {
                BookLinkedList_addArray(booklistFounded, tempNode->array);
                break;
            }
        }
        tempNode =tempNode->next;
    }
    return booklistFounded;
}

BookArray find_book_by_title (const char *title)
{
    unsigned int length = strlen(title);
    BookArray* tempNode = bookList->head->next;
    for(int i = 0; i < bookList->size; ++i)
    {
        for(int k = 0; k < tempNode->array->titleLength; ++k)
        {
            if(length + k > tempNode->array->titleLength)
                break;
            if(strncmp(Book_getTitle(tempNode->array) + k, title, length) == 0)
                return *tempNode;
        }
        tempNode =tempNode->next;
    }
    tempNode = BookArray_new();
    tempNode->length = 0;
    return *tempNode;
}
BookLinkedList* BookLinkedList_findBookbyAuthors(const char* author)
{
    int length = strlen(author);
    BookLinkedList* booklistFounded = BookLinkedList_new();
    BookArray* tempNode = bookList->head->next;
    for(int i = 0; i < bookList->size; ++i)
    {
        for(int k = 0; k < tempNode->array->authorsLength; ++k)
        {
            if(length + k > tempNode->array->authorsLength)
                break;
            if(strncmp(Book_getAuthors(tempNode->array) + k, author, length) == 0)
            {
                BookLinkedList_addArray(booklistFounded, tempNode->array);
                break;
            }
        }
        tempNode =tempNode->next;
    }
    return booklistFounded;
}
BookArray find_book_by_author (const char *author)
{
    BookArray* tempNode = bookList->head->next;
    for(int i = 0; i < bookList->size; ++i)
    {
        if(Book_getAuthors(tempNode->array) == author)
            return *tempNode;
    }
    printf("Sorry , there is no book title named %s\n", author);
    tempNode =BookArray_new();
    tempNode->length = 0;
    return *tempNode;
}

BookArray find_book_by_year (unsigned int year)
{
    BookArray* tempNode = bookList->head->next;
    for(int i = 0; i < bookList->size; ++i)
    {
        if(Book_getYear(tempNode->array) == year)
            return *tempNode;
        tempNode = tempNode->next;
    }
    printf("Sorry , there is no book title named %d\n", year);
    tempNode =BookArray_new();
    tempNode->length = 0;
    return *tempNode;
}

BookLinkedList* BookLinkedList_findBookbyYear(unsigned int year)
{
    BookLinkedList* booklistFounded = BookLinkedList_new();
    BookArray* tempNode = bookList->head->next;
    for(unsigned int i = 0; i < bookList->size; ++i)
    {
        if(tempNode->array->year == year)
            BookLinkedList_addArray(booklistFounded, tempNode->array);
        tempNode = tempNode->next;
    }
    return booklistFounded;
}

int store_books(FILE *file)
{
    file = fopen("bookLibrary.bin", "wb+");
    if(file == NULL)
        return 1;
    fwrite(&(bookList->size), sizeof(int), 1, file);
    BookArray* tempNode = bookList->head->next;
    for(int i = 0; i < bookList->size; ++i)
    {
        fwrite(&(tempNode->array->id), sizeof(unsigned int), 1, file);
        fwrite(&(tempNode->array->titleLength), sizeof(unsigned int), 1, file);
        fwrite(tempNode->array->title, sizeof(char) * (tempNode->array->titleLength + 1), 1, file);
        fwrite(&(tempNode->array->authorsLength), sizeof(unsigned int), 1, file);
        fwrite(tempNode->array->authors, sizeof(char) * (tempNode->array->authorsLength + 1), 1 ,file);
        fwrite(&(tempNode->array->year), sizeof(unsigned int), 1, file);
        fwrite(&(tempNode->array->copies), sizeof(unsigned int), 1, file);
        fwrite(&(tempNode->array->borrowed), sizeof(int), 1, file);
        tempNode = tempNode->next;
    }
    if(fclose(file) != 0)
        return 1;
    return 0;
}

int load_books(FILE *file)
{
    file = fopen("bookLibrary.bin", "rb+");
    if(file == NULL)
        return 0;
    if(BookLinkedList_free(bookList) == 0)
        bookList = BookLinkedList_new();
    fread(&(bookList->size), sizeof(int), 1, file);
    unsigned int size = bookList->size;
    Book* book = Book_new();
    if(book == NULL)
        return 0;
    for(unsigned int i = 0; i < size; ++i)
    {
        fread(&(book->id), sizeof(unsigned int), 1, file);
        fread(&(book->titleLength), sizeof(unsigned int), 1, file);
        book->title = (char*)malloc(sizeof(char) * (book->titleLength + 1));
        fread(book->title, sizeof(char) * (book->titleLength + 1), 1, file);
        fread(&(book->authorsLength), sizeof(unsigned int), 1, file);
        book->authors = (char*)malloc(sizeof(char) * (book->authorsLength + 1));
        fread(book->authors, sizeof(char) * (book->authorsLength + 1), 1, file);
        fread(&(book->year), sizeof(unsigned int), 1, file);
        fread(&(book->copies), sizeof(unsigned int), 1, file);
        fread(&(book->borrowed),sizeof(int), 1, file);
        BookLinkedList_loadArray(bookList, book);
    }
    bookList->size = size;
    if(fclose(file) != 0)
        return 1;
    Book_free(book);
    return 0;
}
/* Operations on BookLinkedList */