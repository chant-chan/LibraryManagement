//
// Created by 陈浩东 on 2021/3/11.
//

#include "book_management.h"
#include <stdlib.h>
#include <string.h>

/*Operation on book*/
Book* Book_new()
{
    Book* tempNode = (Book*)malloc(sizeof(Book));
    if(tempNode == NULL)
    {
        printf("Error -> Book_new: failed to allocate ram for Book\n");
    }
    return tempNode;
}

Book* Book_newWithValue(unsigned int id,char* title, char* authors, unsigned int year, unsigned int copies)
{
    Book* tempNode = Book_new();
    if(tempNode == NULL)
        return NULL;
    tempNode->id = id;
    tempNode->titleLength = (unsigned int)strlen(title);
    tempNode->title = (char*)malloc((tempNode->titleLength + 1) * sizeof(char));
    for(unsigned int i = tempNode->titleLength, bound = -1; i != bound; --i)
        *(tempNode->title + i) = *(title + i);
    tempNode->authorsLength = (unsigned int)strlen(authors);
    tempNode->authors = (char*)malloc((tempNode->authorsLength + 1) * sizeof(char));
    for(unsigned int i = tempNode->authorsLength, bound = -1; i != bound; --i)
        *(tempNode->authors + i) = *(authors + i);
    tempNode->year = year;
    tempNode->copies = copies;
    tempNode->borrowed = 0;
/*    printf("func > Book_newWithValue id %d\n", tempNode->id);
    printf("func > Book_newWithValue title %s\n", tempNode->title);
    printf("func > Book_newWithValue authors %s\n", tempNode->authors);
    printf("func > Book_newWithValue year %d\n", tempNode->year);
    printf("func > Book_newWithValue copies %d\n", tempNode->copies);*/
    return tempNode;
}

void Book_free(Book* target)
{
    if(target == NULL)
    {
        printf("Error -> Book_free: Book to free is  NULL\n");
        return;
    }
    free(target->title);
    printf("successfully free target->title.\n");
    free(target->authors);
    printf("successfully free target->authors.\n");
    free(target);
}

unsigned int Book_getID(Book* target)
{
    if(target == NULL)
    {
        printf("Error -> Book_getID: Book to get id is NULL\n");
        return NULL;
    }
    return target->id;
}

char* Book_getTitle(Book* target)
{
    if(target == NULL)
    {
        printf("Error -> Book_getTitle: Book to get title is NULL\n");
        return NULL;
    }
    return target->title;
}

char* Book_getAuthors(Book* target)
{
    if(target == NULL)
    {
        printf("Error -> Book_getAuthors: Book to get authors is NULL\n");
        return NULL;
    }
    return target->authors;
}

unsigned int Book_getYear(Book* target)
{
    if(target == NULL)
    {
        printf("Error -> Book_getYear: Book to get year is NULL\n");
        return NULL;
    }
    return target->year;
}

unsigned int Book_getCopies(Book* target)
{
    if(target == NULL)
    {
        printf("Error -> Book_getYear: Book to get copies is NULL\n");
        return NULL;
    }
    return target->copies;
}
int Book_getBorrowed(Book* target)
{
    if(target == NULL)
    {
        printf("error -> Book_getBorrowed: Book to get borrowed is NULL\n");
        return NULL;
    }
    return target->borrowed;
}
/*Operation on book*/


